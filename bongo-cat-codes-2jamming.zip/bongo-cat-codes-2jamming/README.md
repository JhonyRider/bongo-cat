# Bongo Cat Codes #2 - Jamming

A Pen created on CodePen.io. Original URL: [https://codepen.io/Jonathan-Gonzalez-the-builder/pen/dyxogGP](https://codepen.io/Jonathan-Gonzalez-the-builder/pen/dyxogGP).

A variation on an older pen: https://codepen.io/carolineartz/pen/VwYwZaP 

beyond the obvious differences, this version uses gsap vs the linked pen animates via css.